param(
    $DatabricksResourceGroupName,
    $DatabricksWorkspaceName,
    $DevOpsProjectName,
    $DevOpsOrganizationUrl,
    $EnvironmentalVariableGroupName
)

# Get Databricks resource details
Write-Host "Getting Databricks resource details."

$databricksResource = (az resource show --resource-type Microsoft.Databricks/workspaces -g "$DatabricksResourceGroupName" -n "$DatabricksWorkspaceName") | ConvertFrom-Json

$databricksWorkspaceId = $databricksResource.id
$databricksWorkspaceUrl = $databricksResource.properties.workspaceUrl

# Get a token for the global Databricks application.
# The resource name is fixed and never changes.
Write-Host "Getting global Databricks token."
$globalDatabricksToken = $(az account get-access-token --resource 2ff814a6-3304-4ab8-85cb-cd0e6f879c1d --query accessToken -o tsv)

# Get a token for the Azure management API
Write-Host "Getting Azure Management API token."
$managementToken = $(az account get-access-token --resource https://management.core.windows.net/ --query accessToken -o tsv)

# Generate a new PAT token
Write-Host "Generating Databricks PAT token."

$body = @{
  comment = "Token created by CI/CD process."
  lifetime_seconds = 7200
} | ConvertTo-Json

$tokenResponse = (Invoke-WebRequest `
  -Uri "https://$databricksWorkspaceUrl/api/2.0/token/create" `
  -Headers @{"Authorization" = "Bearer $globalDatabricksToken"; "X-Databricks-Azure-SP-Management-Token" = "$managementToken"; "X-Databricks-Azure-Workspace-Resource-Id" = "$databricksWorkspaceId";} `
  -Body $body `
  -Method "POST").Content | ConvertFrom-Json

$token = $tokenResponse.token_value

# Get the variable group ID
$EnvironmentalGroupDetails = az pipelines variable-group list `
    --org $DevOpsOrganizationUrl `
    --project "$DevOpsProjectName" `
    --group-name "$EnvironmentalVariableGroupName"
    | ConvertFrom-Json

$variableGroupId = $EnvironmentalGroupDetails.id

Write-Host "Variable Group ID: $variableGroupId, Variable Group Name: $EnvironmentalVariableGroupName, Project: $DevOpsProjectName, Organization: $DevOpsOrganizationUrl"

# Update the token to the variable group as a secret (variable must exist)
az pipelines variable-group variable update `
  --group-id $variableGroupId `
  --name "DatabricksWorkspace.Token" `
  --value $token `
  --org $DevOpsOrganizationUrl `
  --project $DevOpsProjectName `
  --secret true

# Make updated variables available to the current pipeline (as secret where applicable)
Write-Host "##vso[task.setvariable variable=DatabricksWorkspace.Token;issecret=true]$token"