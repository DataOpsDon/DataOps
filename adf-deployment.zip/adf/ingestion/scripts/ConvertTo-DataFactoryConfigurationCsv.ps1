param (
  $InputFilePath = "../config/data-factory-replacements.json",
  $OutputFilePath = "../config/data-factory-replacements.csv",
  $GlobalVariablesFilePath = "../../framework/deployment-variables/GLOBAL.yml",
  $EnvironmentVariablesFilePath = "../../framework/deployment-variables/dev.yml"
)

Install-Module powershell-yaml -Force

# Function that capitalizes the input environment name (dev, prod, etc.) that is dynamically passed in for the Azure Pipeline
# This is necessary to get the pipeline to read these files.
# GLOBAL.yml is hardcoded as capitalized in the pipeline arguments, so doesn't need to be capitalized here.
function Get-CorrectVariablesFilename ($Path){
  $folder = $Path.Substring(0, $Path.LastIndexOf("/") + 1)
  $filename = $Path.Substring($Path.LastIndexOf("/") + 1, $Path.LastIndexOf(".") - $Path.LastIndexOf("/") - 1).ToUpper()
  $extension = $Path.Substring($Path.LastIndexOf("."))
  return "$folder$filename$extension"
}

$EnvironmentVariablesFilePath = Get-CorrectVariablesFilename -Path $EnvironmentVariablesFilePath

function Get-YamlVariables ($Path) {
  $yamlContent = (Get-Content -Path $Path) -join "`n"
  $yamlVariables = ConvertFrom-Yaml -Yaml $yamlContent
  return $yamlVariables.variables
}

$globalVariables = Get-YamlVariables -Path $GlobalVariablesFilePath
$envVariables = Get-YamlVariables -Path $EnvironmentVariablesFilePath

$combinedVariables = @($globalVariables + $envVariables)

function Get-EnvironmentVariableValue ($Name) {    
  $environmentVariableName = $Name.ToUpper() -replace '\.', '_'
  Write-Host "Getting replacement value from $environmentVariableName environment variable."

  return [System.Environment]::GetEnvironmentVariable($environmentVariableName)
}

# return the variable value on matching the input parameter name, null if no matches
function Search-Variables ($Name, $Variables){
  foreach ($variable in $Variables) {
    if ($variable.name -eq $Name) {
      return $variable.value
    }
  }
  return $null
}

function Get-DeploymentVariableValue ($Name, $Variables) {
  Write-Host "Getting YAML replacement value from $Name environment variable."
  # search through both global and environment deployment variable arrays
  $deploymentVariableValue = Search-Variables -Name $Name -Variables $Variables
  return $deploymentVariableValue
}
$settingReplacements = Get-Content $InputFilePath | ConvertFrom-Json
$outputValues = New-Object System.Collections.ArrayList

foreach ($replacement in $settingReplacements) {
  if ($null -ne $replacement.value.environmentVariable) { # takes the name from input JSON if the value is not null there
    $value = Get-DeploymentVariableValue -Name $replacement.value.environmentVariable -Variables $combinedVariables
    # if variable name not in YAML files, look in original system environment
    if ($null -eq $value){
      $value = Get-EnvironmentVariableValue -Name $replacement.value.environmentVariable
    }
  }
  else {
    $value = $replacement.value.staticValue
  }

  $output = New-Object -TypeName psobject 
  $output | Add-Member -MemberType NoteProperty -Name type -Value $replacement.type
  $output | Add-Member -MemberType NoteProperty -Name name -Value $replacement.name
  $output | Add-Member -MemberType NoteProperty -Name path -Value $replacement.path
  $output | Add-Member -MemberType NoteProperty -Name value -Value $value

  $outputValues.Add($output) | Out-Null
}

$outputValues | Export-Csv -Path $OutputFilePath -Delimiter "," -NoTypeInformation