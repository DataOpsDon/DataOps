Param(
    [string] $ResourceGroupName,
    [string] $DataFactoryName,
    [string] $CommonResourceGroupName = "",
    [string] $CommonDataFactoryName = "",
    [string] $SubscriptionId,
    [string] $SelfHostedIRName
)
function Create-ADFPermissions () {

    $Role=Get-AzRoleAssignment `
        -ObjectId $DataFactory.Identity.PrincipalId `
        -Scope $SharedIRId
    
    If($Role.RoleAssignmentName -ne "Contributor"){

    # Create RBAC on the Shared Data Factory assigning the Environmental Data Factory Contributor rights.
    # ObjectId is the MSI of the Environmental Data Factory 
    New-AzRoleAssignment `
        -ObjectId $DataFactory.Identity.PrincipalId `
        -RoleDefinitionName "Contributor" `
        -Scope $SharedIRId
    }

    # Sleep allows permissions above to propagate before creating IR.
    Start-Sleep -s 60

    # Create a linked self-hosted integration runtime within environmental ADF.
    Set-AzDataFactoryV2IntegrationRuntime `
        -ResourceGroupName $ResourceGroupName `
        -DataFactoryName $DataFactoryName `
        -Name "$SelfHostedIRName" `
        -Type "SelfHosted" `
        -SharedIntegrationRuntimeResourceId $SharedIRId `
        -Description ("Linked " + "$SelfHostedIRName" + " Integration Runtime to -" + $SharedDataFactoryName + " within Resource Group " + $SharedResourceGroupName)
}

If($CommonResourceGroupName -ne "" -and $CommonDataFactoryName -ne "") {

    Install-Module Az.DataFactory -MinimumVersion "1.10.0" -Force
    Install-Module -Name "azure.datafactory.tools" -Force
    Import-Module -Name "azure.datafactory.tools" -Force
    Install-Module Az.Resources -Force

    Write-Host ("ResourceGroupName: " + $ResourceGroupName)
    Write-Host ("DataFactoryName: " + $DataFactoryName)
    Write-Host ("CommonResourceGroupName: " + $CommonResourceGroupName)
    Write-Host ("CommonDataFactoryName: " + $CommonDataFactoryName)
    Write-Host ("SubscriptionId: " + $SubscriptionId)
    Write-Host ("SelfHostedIRName: " + $SelfHostedIRName)

    # Get Environmental ADF details.
    $DataFactory = Get-AzDataFactoryV2 -ResourceGroupName "$ResourceGroupName" -Name "$DataFactoryName"
    Write-Host ("Environmental Data Factory: " + $DataFactory)

    # Get Shared IR details.
    $SharedIRId = ("/subscriptions/" + $SubscriptionId + "/resourceGroups/"+ "$CommonResourceGroupName" + "/providers/Microsoft.DataFactory/factories/" + "$CommonDataFactoryName" + "/integrationruntimes/" + $SelfHostedIRName)
    Write-Host ("Shared IR: " + $SharedIRId)

    # Needs to be existing in Environmental IR otherwise it will error with "Operation returned an invalid status code NotFound".
    # Get Environmental IR details.
    $EnvironmentalIR = Get-AzDataFactoryV2IntegrationRuntime -ResourceGroupName "$ResourceGroupName" -DataFactoryName "$DataFactoryName" -Name "$SelfHostedIRName" -Status -ErrorAction SilentlyContinue
    Write-Host ("Environmental IR: " + $EnvironmentalIR.Name)

    # If Self-Hosted-IR exists already don't proceed else call function to create everything.
    If ($EnvironmentalIR.Name -ne "" -and $EnvironmentalIR.Name -ne $null) {
        Write-Host "Permissions and Shared IR already created."
        } Else {
            Create-ADFPermissions       
            Write-Host "Permission between ADF and Shared ADF IR has been created"
        }
}
Else
{
   Write-Host "No ComonResourceGroupName or CommonDataFactoryName set - so no shared IR set"    
}